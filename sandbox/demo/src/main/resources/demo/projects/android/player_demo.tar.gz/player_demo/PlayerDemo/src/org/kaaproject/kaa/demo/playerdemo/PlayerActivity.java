/*
 * Copyright 2014 CyberVision, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.kaaproject.kaa.demo.playerdemo;

import org.kaaproject.kaa.demo.playerdemo.data.DeviceInfoEntry;

import android.os.Bundle;
import android.support.v4.app.FragmentManager;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBar;
import android.support.v7.app.ActionBarActivity;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;

public class PlayerActivity extends ActionBarActivity implements
        DevicesDrawerFragment.DeviceDrawerCallbacks {

    /** The left navigation drawer with list of devices. */
    private DevicesDrawerFragment mNavigationDrawerFragment;
    
    /** Current fragment with song list retrieved from device. */
    private SongListFragment mCurrentSongList;

    /** Current activity title. */
    private CharSequence mTitle;
    
    /** Current selected device info. */
    private DeviceInfoEntry mCurrentDevice;
    
    /** Controller based on Kaa client SDK API. Implements sending and handling events of PlayerClassFamily. */
    private PlayerController mPlayerController;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mPlayerController = new PlayerController(this);

        mNavigationDrawerFragment = (DevicesDrawerFragment) getSupportFragmentManager()
                .findFragmentById(R.id.navigation_drawer);
        mTitle = getTitle();

        /** Set up the drawer UI and initialization of player controller. */
        mNavigationDrawerFragment.setUp(R.id.navigation_drawer,
                (DrawerLayout) findViewById(R.id.drawer_layout));
        
    }
    

    
    public PlayerController getPlayerController() {
        return mPlayerController;
    }
    
    @Override
    protected void onDestroy() {
        if (mPlayerController != null) {
            mPlayerController.stop();
        }
        super.onDestroy();
    }

    @Override
    public void onDeviceItemSelected(DeviceInfoEntry deviceInfo) {
        if (mCurrentDevice == null || 
                !mCurrentDevice.getEndpointKey().equals(deviceInfo.getEndpointKey())) {
            // update the main content by replacing fragments
            mCurrentDevice = deviceInfo;
            FragmentManager fragmentManager = getSupportFragmentManager();
            mCurrentSongList = SongListFragment.newInstance(deviceInfo);
            fragmentManager
                    .beginTransaction()
                    .replace(R.id.container,
                    		mCurrentSongList).commit();
            mTitle = deviceInfo.getDeviceInfo().getModel();
        }
    }

    public void restoreActionBar() {
        ActionBar actionBar = getSupportActionBar();
        actionBar.setNavigationMode(ActionBar.NAVIGATION_MODE_STANDARD);
        actionBar.setDisplayShowCustomEnabled(true);
        actionBar.setDisplayShowTitleEnabled(false);
        
        LayoutInflater inflator = LayoutInflater.from(this);
        View v = inflator.inflate(R.layout.custom_title, null);
        
        ((TextView)v.findViewById(R.id.title)).setText(mTitle);
        ((TextView)v.findViewById(R.id.title)).setSelected(true);
        actionBar.setCustomView(v);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        if (!mNavigationDrawerFragment.isDrawerOpen()) {
            getMenuInflater().inflate(R.menu.main, menu);
            restoreActionBar();
            return true;
        }
        else {
        	getMenuInflater().inflate(R.menu.global, menu);
        	ActionBar actionBar = getSupportActionBar();
        	actionBar.setDisplayShowTitleEnabled(true);
        	actionBar.setDisplayShowCustomEnabled(false);
        	actionBar.setNavigationMode(ActionBar.NAVIGATION_MODE_STANDARD);
        	actionBar.setTitle(R.string.app_name);
        }
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (mNavigationDrawerFragment.getDrawerToggle() != null &&
        		mNavigationDrawerFragment.getDrawerToggle().onOptionsItemSelected(item)) {
            return true;
        }
        int id = item.getItemId();
        if (id == R.id.action_settings) {
            return true;
        }
        if (id == R.id.action_refresh) {
        	if (mCurrentSongList != null) {
        		mCurrentSongList.refresh();
        	}
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

}
