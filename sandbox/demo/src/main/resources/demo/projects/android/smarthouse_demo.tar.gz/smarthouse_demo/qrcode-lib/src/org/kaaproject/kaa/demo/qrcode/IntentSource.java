
package org.kaaproject.kaa.demo.qrcode;

enum IntentSource {

  NATIVE_APP_INTENT,
  NONE

}
