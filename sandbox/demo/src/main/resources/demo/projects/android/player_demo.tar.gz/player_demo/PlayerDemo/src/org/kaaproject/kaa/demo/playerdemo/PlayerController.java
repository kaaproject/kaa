/*
 * Copyright 2014 CyberVision, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.kaaproject.kaa.demo.playerdemo;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.kaaproject.kaa.client.Kaa;
import org.kaaproject.kaa.client.KaaAndroid;
import org.kaaproject.kaa.client.KaaClient;
import org.kaaproject.kaa.client.event.EventFamilyFactory;
import org.kaaproject.kaa.demo.player.BatteryInfoRequest;
import org.kaaproject.kaa.demo.player.BatteryInfoResponse;
import org.kaaproject.kaa.demo.player.DeviceInfo;
import org.kaaproject.kaa.demo.player.DeviceInfoRequest;
import org.kaaproject.kaa.demo.player.DeviceInfoResponse;
import org.kaaproject.kaa.demo.player.PauseRequest;
import org.kaaproject.kaa.demo.player.PlayListRequest;
import org.kaaproject.kaa.demo.player.PlayListResponse;
import org.kaaproject.kaa.demo.player.PlayRequest;
import org.kaaproject.kaa.demo.player.PlaybackInfo;
import org.kaaproject.kaa.demo.player.PlaybackInfoRequest;
import org.kaaproject.kaa.demo.player.PlaybackInfoResponse;
import org.kaaproject.kaa.demo.player.PlaybackStatus;
import org.kaaproject.kaa.demo.player.PlayerClassFamily;
import org.kaaproject.kaa.demo.player.PlayerClassFamily.DefaultEventFamilyListener;
import org.kaaproject.kaa.demo.player.SongInfo;
import org.kaaproject.kaa.demo.player.StopRequest;
import org.kaaproject.kaa.demo.playerdemo.command.AttachUserCommand;
import org.kaaproject.kaa.demo.playerdemo.command.CommandAsyncTask;
import org.kaaproject.kaa.demo.playerdemo.command.CommandCallback;
import org.kaaproject.kaa.demo.playerdemo.command.EndpointCommandKey;
import org.kaaproject.kaa.demo.playerdemo.command.GetDeviceInfoCommand;
import org.kaaproject.kaa.demo.playerdemo.command.GetEndpointKeyListCommand;
import org.kaaproject.kaa.demo.playerdemo.command.GetPlayListCommand;
import org.kaaproject.kaa.demo.playerdemo.command.GetPlaybackInfoCommand;
import org.kaaproject.kaa.demo.playerdemo.concurrent.BlockingCallable;
import org.kaaproject.kaa.demo.playerdemo.concurrent.TimeoutExecutor;
import org.kaaproject.kaa.demo.playerdemo.profile.PlayerProfileContainer;

import android.content.ContentResolver;
import android.content.ContentUris;
import android.content.Context;
import android.database.Cursor;
import android.media.MediaPlayer;
import android.net.Uri;
import android.util.Log;

/** Controller based on Kaa client SDK API. Implements sending and handling events of PlayerClassFamily. */
public class PlayerController implements DefaultEventFamilyListener {
    
    /** Default timeout for commands in milliseconds */
    private static final long DEFAULT_TASK_TIMEOUT = 10000;
    
    /** Android application context */
    private Context context;
    
    /** Reference to Kaa client SDK */
    private Kaa kaa;
    
    /** Reference to Kaa client */
    private KaaClient client;
    
    /** Reference to event class family used to send events */
    private PlayerClassFamily players;
    
    /** Flag indicating that Kaa client SDK was initialized */
    private boolean inited = false;
    
    /** Flag indicating that command to attach current endpoint was successfully executed */
    private boolean userAttached = false;
    
    /** Executor to concurrently process commands with specified timeout */
    private TimeoutExecutor executor;
    
    /** Map to store issued commands. Used to find corresponding command and set result when receiving event */ 
    private Map<EndpointCommandKey, BlockingCallable<?>> commandMap = new HashMap<>();
    
    /** Instance of android media player used for music playback */
    private MediaPlayer player;
    
    /** Current device info. Prepared before Kaa client initialization. */ 
    private DeviceInfo deviceInfo;
    
    /** Current device song list. Prepared before Kaa client initialization. */ 
    private List<SongInfo> playList;
    
    /** Latest song url played by device. */
    private String currentSongUrl;
    
    public PlayerController(Context context) {
        this.context = context;
        this.executor = new TimeoutExecutor();
    }
    
    /** Execute initialization of Kaa client in background. */
    public void init(CommandCallback<Void> callback) {
    	new CommandAsyncTask<Void,Void>(callback) {
			@Override
			protected Void executeCommand(Void... params) throws Throwable {
			    /** Set up device info and prepare play list. */
				initData();
				/** Create media player instance.*/
				player = new MediaPlayer();
				/** Set up Kaa client SDK */
				inited = new StartKaa().execute(executor, DEFAULT_TASK_TIMEOUT*3);
        		/** Attach current endpoint to user with predefined external UID. */
        		userAttached = new AttachUserCommand(client).execute(executor, DEFAULT_TASK_TIMEOUT);
				return null;
			}
    	}.execute();
    }
    
    /** Stop Kaa client and release resourceEndpointKeys */
    public void stop() {
        if (inited) {
            if (kaa != null) {
                kaa.stop();
            }
            inited = false;
            userAttached = false;
        }
    }
        
    /** Get list of endpoint keys which attached to current user account and can handle 
     *  events of PlayerClassFamily.
     */
    public void getEndpointKeyList(CommandCallback<List<String>> callback) {
    	new CommandAsyncTask<Void,List<String>>(callback) {
			@Override
			protected List<String> executeCommand(Void... params) throws Throwable {
				if (!inited) {
				    inited = new StartKaa().execute(executor, DEFAULT_TASK_TIMEOUT);
				}
				if (!userAttached) {
				    userAttached = new AttachUserCommand(client).execute(executor, DEFAULT_TASK_TIMEOUT);
				}
				return new GetEndpointKeyListCommand(client).execute(executor, DEFAULT_TASK_TIMEOUT);
			}
    	}.execute();
    }
    
    /** Get device info by issuing DeviceInfoRequest event to endpoint 
     *  identified by endpontKey.
     */
    public void getDeviceInfo(String endpontKey, CommandCallback<DeviceInfoResponse> callback) {
    	checkInited();
       	new CommandAsyncTask<String,DeviceInfoResponse>(callback) {
    			@Override
    			protected DeviceInfoResponse executeCommand(String... endpontKey) throws Throwable {
    				return new GetDeviceInfoCommand(commandMap, 
    				        players, 
    				        endpontKey[0]).execute(executor, DEFAULT_TASK_TIMEOUT);
    			}
        }.execute(endpontKey);
    }
    
    /** Get list of song info by issuing PlayListRequest event to endpoint 
     *  identified by endpontKey.
     */
    public void getPlayList(String endpontKey, CommandCallback<PlayListResponse> callback) {
    	checkInited();
       	new CommandAsyncTask<String,PlayListResponse>(callback) {
    			@Override
    			protected PlayListResponse executeCommand(String... endpontKey) throws Throwable {
    				return new GetPlayListCommand(commandMap, 
                            players, 
                            endpontKey[0]).execute(executor, DEFAULT_TASK_TIMEOUT);
    			}
        }.execute(endpontKey);
    }
    
    /** Get current playback info by issuing PlaybackInfoRequest event to endpoint 
     *  identified by endpontKey.
     */
    public void getPlaybackInfo(String endpontKey, CommandCallback<PlaybackInfoResponse> callback) {
    	checkInited();
       	new CommandAsyncTask<String,PlaybackInfoResponse>(callback) {
    			@Override
    			protected PlaybackInfoResponse executeCommand(String... endpontKey) throws Throwable {
    				return new GetPlaybackInfoCommand(commandMap, 
                            players, 
                            endpontKey[0]).execute(executor, DEFAULT_TASK_TIMEOUT);
    			}
        }.execute(endpontKey);
    }

    /** Initiate playback of specified url by issuing PlayRequest event to endpoint 
     *  identified by endpontKey.
     */    
    public void playUrl(String endpontKey, String url) {
    	checkInited();
        PlayRequest playRequest = new PlayRequest();
        playRequest.setUrl(url);
        players.sendEvent(playRequest, endpontKey);
    }
    
    /** Initiate pause by issuing PauseRequest event to endpoint 
     *  identified by endpontKey.
     */   
    public void pause(String endpontKey) {
    	checkInited();
        PauseRequest pauseRequest = new PauseRequest();
        players.sendEvent(pauseRequest, endpontKey);
    }
    
    /** PlayerClassFamily.DefaultEventFamilyListener methods. */
    
    /** Handle device info response from endpoint identified by sourceEndpointKey. */
    @Override
    public void onEvent(DeviceInfoResponse deviceInfoResponse, String sourceEndpointKey) {
        Log.d("Kaa", "Device info response recieved");
        onResponse(sourceEndpointKey, deviceInfoResponse, DeviceInfoResponse.class);
    }

    /** Handle play list response from endpoint identified by sourceEndpointKey. */
    @Override
    public void onEvent(PlayListResponse playListResponse, String sourceEndpointKey) {
        Log.d("Kaa", "Play list response recieved");
        onResponse(sourceEndpointKey, playListResponse, PlayListResponse.class);
    }

    /** Handle payback info response from endpoint identified by sourceEndpointKey. */
    @Override
    public void onEvent(PlaybackInfoResponse playbackInfoResponse, String sourceEndpointKey) {
        Log.d("Kaa", "Playback info response recieved");
        onResponse(sourceEndpointKey, playbackInfoResponse, PlaybackInfoResponse.class);
    }

    /** Handle battery info response from endpoint identified by sourceEndpointKey. */
    @Override
    public void onEvent(BatteryInfoResponse batteryInfoResponse, String sourceEndpointKey) {
        Log.d("Kaa", "Battery info response recieved");
        onResponse(sourceEndpointKey, batteryInfoResponse, BatteryInfoResponse.class);
    }

    /** Handle device info request from endpoint identified by sourceEndpointKey. 
     *  Send device info in response. */
    @Override
    public void onEvent(DeviceInfoRequest deviceInfoRequest, String sourceEndpointKey) {
        DeviceInfoResponse response = new DeviceInfoResponse();
        response.setDeviceInfo(deviceInfo);
        players.sendEvent(response, sourceEndpointKey);
    }

    /** Handle play list request from endpoint identified by sourceEndpointKey. 
     *  Send play list in response. */
    @Override
    public void onEvent(PlayListRequest playListRequest, String sourceEndpointKey) {
        PlayListResponse response = new PlayListResponse();
        response.setPlayList(playList);
        players.sendEvent(response, sourceEndpointKey);    
    }

    /** Handle playback info request from endpoint identified by sourceEndpointKey. 
     *  Send playback info in response. */
    @Override
    public void onEvent(PlaybackInfoRequest playbackInfoRequest, String sourceEndpointKey) {
        PlaybackInfo playbackInfo = new PlaybackInfo();
        playbackInfo.setUrl(currentSongUrl);
        playbackInfo.setStatus(player.isPlaying() ? PlaybackStatus.PLAYING : PlaybackStatus.PAUSED);
        playbackInfo.setTime(player.getCurrentPosition());
        PlaybackInfoResponse response = new PlaybackInfoResponse();
        response.setPlaybackInfo(playbackInfo);
        players.sendEvent(response, sourceEndpointKey);
    }

    /** Handle play request from endpoint identified by sourceEndpointKey. */
    @Override
    public void onEvent(PlayRequest playRequest, String sourceEndpointKey) {
        if (playRequest.getUrl() != null) {
          if (currentSongUrl == null || !currentSongUrl.equals(playRequest.getUrl())) {
              playUrl(playRequest.getUrl());
              currentSongUrl = playRequest.getUrl();
          }
          else if (!player.isPlaying()) {
              player.start();
          }
        }   
    }
    
    /** Handle pause request from endpoint identified by sourceEndpointKey. */
    @Override
    public void onEvent(PauseRequest pauseRequest, String sourceEndpointKey) {
        if (player.isPlaying()) {
            player.pause();
        }
    }

    /** Handle stop request from endpoint identified by sourceEndpointKey. */
    @Override
    public void onEvent(StopRequest stopRequest, String sourceEndpointKey) {
    }

    /** Handle battery info request from endpoint identified by sourceEndpointKey. */
    @Override
    public void onEvent(BatteryInfoRequest batteryInfoRequest, String sourceEndpointKey) {
    }
    
    /** Set up device info and prepare play list. */
    private void initData() {
        deviceInfo = new DeviceInfo();
        deviceInfo.setBrand(android.os.Build.BRAND);
        deviceInfo.setDevice(android.os.Build.DEVICE);
        deviceInfo.setManufacturer(android.os.Build.MANUFACTURER);
        deviceInfo.setModel(android.os.Build.MODEL);
        deviceInfo.setProduct(android.os.Build.PRODUCT);
        
        playList = new ArrayList<>();
        ContentResolver musicResolver = context.getContentResolver();
        Uri musicUri = android.provider.MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
        Cursor musicCursor = musicResolver.query(musicUri, null, null, null, null);
        if(musicCursor!=null && musicCursor.moveToFirst()){
            int albumColumn = musicCursor.getColumnIndex
                    (android.provider.MediaStore.Audio.Media.ALBUM);
            int artistColumn = musicCursor.getColumnIndex
                    (android.provider.MediaStore.Audio.Media.ARTIST);
            int displayNameColumn = musicCursor.getColumnIndex
                    (android.provider.MediaStore.Audio.Media.DISPLAY_NAME);
            int durationColumn = musicCursor.getColumnIndex
                    (android.provider.MediaStore.Audio.Media.DURATION);
            int titleColumn = musicCursor.getColumnIndex
                    (android.provider.MediaStore.Audio.Media.TITLE);
            int idColumn = musicCursor.getColumnIndex
                    (android.provider.MediaStore.Audio.Media._ID);
            do {
                String album = musicCursor.getString(albumColumn);
                String artist = musicCursor.getString(artistColumn);
                String displayName = musicCursor.getString(displayNameColumn);
                long duration = musicCursor.getLong(durationColumn);
                String title = musicCursor.getString(titleColumn);
                long id = musicCursor.getLong(idColumn);
                
                SongInfo songInfo = new SongInfo();
                songInfo.setAlbum(album);
                songInfo.setArtist(artist);
                songInfo.setDisplayName(displayName);
                songInfo.setDuration((int)duration);
                songInfo.setTitle(title);
                songInfo.setUrl(id+"");
                
                playList.add(songInfo);
              }
              while (musicCursor.moveToNext());
        }
    }
    
    /** Check if Kaa client SDK is initialized */
    private void checkInited() {
        if (!inited) {
            throw new IllegalStateException("Kaa client SDK is not initialized!");
        }
    }
    
    /** Handle response. Find associated command by endpointKey and event class 
     *  then pass response as command result. */
    @SuppressWarnings("unchecked")
    private <T> void onResponse(String endpontKey, T response, Class<T> clazz) {
        EndpointCommandKey key = new EndpointCommandKey(clazz.getName(), endpontKey);
        BlockingCallable<T> callable = (BlockingCallable<T>) commandMap.remove(key);
        if (callable != null) {
        	callable.onComplete(response);
        }
    }
    
    /** Start url playback by android media player */
	private void playUrl(String url) {
        long songId = Long.valueOf(url);
        Uri trackUri = ContentUris.withAppendedId(
                android.provider.MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
                songId);
        try {
      	  	player.reset();
            player.setDataSource(context, trackUri);
            player.prepare();
            player.start();
        }
        catch (Exception e) {
      	  Log.e("Kaa", "Unable to start playback for uri "+trackUri, e);
        }
	}

    /** Implementation of Kaa client SDK set up command */
    class StartKaa extends BlockingCallable<Boolean> {
        
        StartKaa() {
            super(false);
        }

        @Override
        protected void executeAsync() {
            try {
                Log.d("Kaa", "Initializing Kaa client...");
                kaa = new KaaAndroid(context);
                client = kaa.getClient();
                client.getProfileManager().setProfileContainer(new PlayerProfileContainer());
                EventFamilyFactory eventFamilyFactory = kaa.getClient().getEventFamilyFactory();
                players = eventFamilyFactory.getPlayerClassFamily();
                players.addListener(PlayerController.this);
                kaa.start();
                Log.d("Kaa", "Kaa client initialization completed.");
                onComplete(true);
            } catch (Exception e) {
                Log.e("Kaa", "Kaa client initialization failed.", e);
                onException(e);
            }
        }
    }
        
}
