/*
 * Copyright 2014 CyberVision, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.kaaproject.kaa.demo.playerdemo.command;

import java.util.Arrays;
import java.util.List;

import org.kaaproject.kaa.client.KaaClient;
import org.kaaproject.kaa.client.event.FetchEventListeners;
import org.kaaproject.kaa.demo.player.BatteryInfoRequest;
import org.kaaproject.kaa.demo.player.DeviceInfoRequest;
import org.kaaproject.kaa.demo.player.PauseRequest;
import org.kaaproject.kaa.demo.player.PlayListRequest;
import org.kaaproject.kaa.demo.player.PlayRequest;
import org.kaaproject.kaa.demo.player.PlaybackInfoRequest;
import org.kaaproject.kaa.demo.player.StopRequest;
import org.kaaproject.kaa.demo.playerdemo.exception.PlayerException;

import android.util.Log;

/** Implementation of get list of endpoint keys command.
 */
public class GetEndpointKeyListCommand extends AbstractClientCommand<List<String>> {

        public GetEndpointKeyListCommand(KaaClient client) {
            super(client);
        }

        @Override
        protected void executeAsync() {
            List<String> fqns = Arrays.asList(DeviceInfoRequest.class.getName(),
                    PlayListRequest.class.getName(),
                    PlaybackInfoRequest.class.getName(),
                    PlayRequest.class.getName(),
                    PauseRequest.class.getName(),
                    StopRequest.class.getName(),
                    BatteryInfoRequest.class.getName());
            client.getEventListenerResolver().findEventListeners(fqns, new FetchEventListeners() {
                @Override
                public void onEventListenersReceived(
                        List<String> endpontKeys) {
                    Log.d("Kaa", "Got list of attached enpoint keys, size " + endpontKeys.size());
                    onComplete(endpontKeys);
                }
    
                @Override
                public void onRequestFailed() {
                    Log.e("Kaa", "Unable to get list of available endpoint keys!");
                    onException(new PlayerException("Unable to get list of endpoint keys!"));
                }
            });
        }
    }