/*
 * Copyright 2014 CyberVision, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.kaaproject.kaa.demo.playerdemo;

import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.kaaproject.kaa.demo.player.PlayListResponse;
import org.kaaproject.kaa.demo.player.PlaybackInfoResponse;
import org.kaaproject.kaa.demo.player.PlaybackStatus;
import org.kaaproject.kaa.demo.player.SongInfo;
import org.kaaproject.kaa.demo.playerdemo.command.CommandCallback;
import org.kaaproject.kaa.demo.playerdemo.data.DeviceInfoEntry;

import android.app.Activity;
import android.content.Context;
import android.content.res.TypedArray;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.app.ActionBar;
import android.support.v7.app.ActionBarActivity;
import android.util.Log;
import android.util.SparseIntArray;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.SectionIndexer;
import android.widget.TextView;

public class SongListFragment extends Fragment {

    private static final String ARG_ENDPOINT_KEY = "endpoint_key";

    private PlayerActivity mMainActivity;
    private String mEndpointKey;

    private ListView mSongsListView;
    private TextView mErrorTextView;
    private ProgressBar mSongsProgressBar;
    private SongInfoAdapter mSongsAdapter;

    private TextView mCurrentSongNameView;
    private TextView mCurrentSongDetailsView;
    private Button mCurrentSongActionButton;
    
    private SongInfo mCurrentSong;
    private PlaybackStatus mCurrentPlaybackStatus = PlaybackStatus.PAUSED;
    
    public static SongListFragment newInstance(DeviceInfoEntry deviceInfo) {
        SongListFragment fragment = new SongListFragment();
        Bundle args = new Bundle();
        args.putString(ARG_ENDPOINT_KEY, deviceInfo.getEndpointKey());
        fragment.setArguments(args);
        return fragment;
    }

    public SongListFragment() {
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
            Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.song_list, container, false);

        mSongsListView = (ListView) view.findViewById(R.id.songsList);
        mErrorTextView = (TextView) view.findViewById(R.id.errorTextView);
        mSongsProgressBar = (ProgressBar) view.findViewById(R.id.progress);
        mSongsListView
                .setOnItemClickListener(new AdapterView.OnItemClickListener() {
                    @Override
                    public void onItemClick(AdapterView<?> parent, View view,
                            int position, long id) {
                        selectItem(position, true);
                    }
                });
        
        mCurrentSongNameView = (TextView) view.findViewById(R.id.currentSongName);
        mCurrentSongDetailsView = (TextView) view.findViewById(R.id.currentSongDetails);
        mCurrentSongActionButton = (Button) view.findViewById(R.id.currentSongAction);
        mCurrentSongNameView.setSelected(true);
        mCurrentSongDetailsView.setSelected(true);

        mSongsListView.setFastScrollEnabled(true);
        
        mCurrentSongActionButton.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                togglePlayback();
            }
        });

        return view;
    }
    
    
    
    @Override
	public void onResume() {
		super.onResume();
        mCurrentSongNameView.setSelected(true);
        mCurrentSongDetailsView.setSelected(true);
	}

	public void onTimeout() {
    	mSongsProgressBar.setVisibility(View.GONE);
        mErrorTextView.setVisibility(View.VISIBLE);
        mErrorTextView.setText("Unable to complete request within a given timeout!");
    }
    
    public void onError(final String message) {
    	mSongsProgressBar.setVisibility(View.GONE);
        mErrorTextView.setVisibility(View.VISIBLE);
        mErrorTextView.setText(message);
    }

    private void selectItem(int position, boolean startPlayback) {
        if (mSongsListView != null) {
        	mSongsAdapter.notifyDataSetChanged();
            SongInfo item = mSongsAdapter.getItem(position);
            if (mCurrentSong == null || !mCurrentSong.getUrl().equals(item.getUrl())) {
                mCurrentSong = item;
                mCurrentSongActionButton.setVisibility(View.VISIBLE);
                mCurrentSongNameView.setText(mCurrentSong.getTitle());
                String artist = mCurrentSong.getArtist().contains("unknown") ? 
                        "Unknown artist" : 
                            mCurrentSong.getArtist();
                mCurrentSongDetailsView.setText(artist);
                if (startPlayback) {
                	play();
                }
            }
        }
    }
    
    private void hideSongDetails() {
    	if (mCurrentSongActionButton != null) {
    		mCurrentSongActionButton.setVisibility(View.GONE);
    	}
    	if (mCurrentSongNameView != null) {
    		mCurrentSongNameView.setText("");
    	}
    	if (mCurrentSongDetailsView != null) {
    		mCurrentSongDetailsView.setText("");
    	}
    }
    
    private void togglePlayback() {
        if (mCurrentPlaybackStatus == PlaybackStatus.PAUSED) {
            play();
        }
        else {
            pause();
        }
    }
    
    private void pause() {
        if (mCurrentSong != null) {
        	updateStatus(PlaybackStatus.PAUSED);
            mMainActivity.getPlayerController().pause(mEndpointKey);
        }
    }
    
    private void play() {
        if (mCurrentSong != null) {
        	updateStatus(PlaybackStatus.PLAYING);
            mMainActivity.getPlayerController().playUrl(mEndpointKey, mCurrentSong.getUrl());
        }
    }
    
    private void updateStatus(PlaybackStatus status) {
    	mCurrentPlaybackStatus = status;
    	if (mCurrentPlaybackStatus == PlaybackStatus.PAUSED) {
    		mCurrentSongActionButton.setBackgroundResource(R.drawable.nowplaying_play);
    	}
    	else {
    		mCurrentSongActionButton.setBackgroundResource(R.drawable.nowplaying_pause);
    	}
    }

    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);
        if (activity != null) {
            mEndpointKey = getArguments().getString(ARG_ENDPOINT_KEY);
            mMainActivity = ((PlayerActivity) activity);
            refresh();
        }
    }
    
    public void refresh() {
    	if (mSongsProgressBar != null) {
    		mSongsProgressBar.setVisibility(View.VISIBLE);
    	}
    	if (mErrorTextView != null) {
    		mErrorTextView.setVisibility(View.GONE);
    	}
    	if (mSongsListView != null) {
    		mSongsListView.setVisibility(View.GONE);
    	}
    	mCurrentSong = null;
        hideSongDetails();
    	mMainActivity.getPlayerController().getPlayList(mEndpointKey, new PlayListCallback());
    }
    
    class PlayListCallback implements CommandCallback<PlayListResponse> {

		@Override
		public void onCommandFailure(Throwable t) {
			Log.e("Kaa", "Retrieving list of device songs failed", t);
	        String message;
	        if (t != null) {
	            message = "Unexpected error: " + t.getMessage();
	        }
	        else {
	            message = "Unknown error!";
	        }
	        onError(message);
		}

		@Override
		public void onCommandSuccess(PlayListResponse result) {
			 if (result != null && result.getPlayList() != null) {
                 mSongsAdapter = new SongInfoAdapter(result.getPlayList(),
                         getActionBar().getThemedContext());
                 mSongsProgressBar.setVisibility(View.GONE);
                 mSongsListView.setAdapter(mSongsAdapter);
                 mSongsListView.setVisibility(View.VISIBLE);
                 mSongsAdapter.notifyDataSetChanged();
                 mMainActivity.getPlayerController().getPlaybackInfo(mEndpointKey, new PlaybackInfoCallback());
			 }
		}

		@Override
		public void onCommandTimeout() {
			onTimeout();
		}
    	
    }
    
    class PlaybackInfoCallback implements CommandCallback<PlaybackInfoResponse> {

		@Override
		public void onCommandFailure(Throwable t) {}

		@Override
		public void onCommandSuccess(PlaybackInfoResponse result) {
			if (result.getPlaybackInfo() != null) {
				if (result.getPlaybackInfo().getUrl() != null && mSongsListView != null) {
					int position = mSongsAdapter.getPositionForUrl(result.getPlaybackInfo().getUrl());
					mSongsListView.setItemChecked(position, true);
					selectItem(position, false);
					mSongsListView.setSelection(position);
			        View v = mSongsListView.getChildAt(position);
			        if (v != null) {
			        	v.requestFocus();
			        }
					updateStatus(result.getPlaybackInfo().getStatus());
				}
			}
			
		}

		@Override
		public void onCommandTimeout() {}
    	
    }

    class SongInfoAdapter extends ArrayAdapter<SongInfo> implements SectionIndexer {

        private List<SongInfo> mSongs;
        private Context context;
        private int selectedTextColor;
        private int defTextColor;

        private String[] mAlphabetArray;
        private SparseIntArray mAlphaMap;
        private Map<String,Integer> mUrlPositionMap; 

        public SongInfoAdapter(List<SongInfo> itemList, Context ctx) {
            super(ctx, android.R.layout.simple_list_item_1, itemList);
            this.context = ctx;
            setItemList(itemList);
            int[] textColorPrimaryAttr = new int[] { android.R.attr.textColorPrimary };
            TypedArray a = getActionBar().getThemedContext().obtainStyledAttributes(textColorPrimaryAttr);
            defTextColor = a.getColor(0, -1);
            a.recycle();        
            selectedTextColor = getResources().getColor(R.color.holo_blue_dark);
        }
        
        @Override
        public Object[] getSections() {
            return mAlphabetArray;
        }

        @Override
        public int getPositionForSection(int sectionIndex) {
            return mAlphaMap.get(sectionIndex);
        }
        
        public int getPositionForUrl(String url) {
            return mUrlPositionMap.get(url);
        }

        @Override
        public int getSectionForPosition(int position) {
            if (mSongs.get(position).getTitle().length()>0) {
                char letter = mSongs.get(position).getTitle().toUpperCase().charAt(0);
                for (int i=0;i<mAlphabetArray.length;i++) {
                    if (letter==mAlphabetArray[i].charAt(0)) {
                        return i;
                    }
                }
            }
            return 0;
        }

        @Override
        public int getCount() {
            if (mSongs != null)
                return mSongs.size();
            return 0;
        }

        @Override
        public SongInfo getItem(int position) {
            if (mSongs != null)
                return mSongs.get(position);
            return null;
        }

        @Override
        public long getItemId(int position) {
            if (mSongs != null)
                return mSongs.get(position).hashCode();
            return 0;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            View v = convertView;
            if (v == null) {
                LayoutInflater inflater = (LayoutInflater) context
                        .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
                v = inflater.inflate(R.layout.song_list_item, null);
            }
            SongInfo entry = mSongs.get(position);
            TextView songNameView = (TextView) v.findViewById(R.id.songName);
            
            if (position == mSongsListView.getCheckedItemPosition()) {
                songNameView.setTextColor(selectedTextColor);
            }
            else {
                songNameView.setTextColor(defTextColor);
            }
            
            TextView songDetailsView = (TextView) v
                    .findViewById(R.id.songDetails);
            // View songActionsView = (View) v.findViewById(R.id.songActions);

            songNameView.setText(entry.getTitle());

            int millis = entry.getDuration().intValue();
            String durationString = Utils.milliSecondsToTimer(millis);

            String artist = entry.getArtist().contains("unknown") ? 
                        "Unknown artist" : 
                        entry.getArtist();
            
            String details = String.format("%s (%s)", artist,
                    durationString);
            songDetailsView.setText(details);
            return v;
        }

        public List<SongInfo> getItemList() {
            return mSongs;
        }

        public void setItemList(List<SongInfo> itemList) {
            this.mSongs = itemList;
            Collections.sort(mSongs, new Comparator<SongInfo>() {
                @Override
                public int compare(SongInfo lhs, SongInfo rhs) {
                    return lhs.getTitle().toUpperCase().compareTo(rhs.getTitle().toUpperCase());
                }
            });
            updateSections();
        }
        
        private void updateSections() {
            mAlphaMap = new SparseIntArray();
            mUrlPositionMap = new HashMap<>();
            Set<String> allChars = new LinkedHashSet<String>();
            for (int i=0;i<mSongs.size();i++) {
            	mUrlPositionMap.put(mSongs.get(i).getUrl(), i);
                char letter = mSongs.get(i).getTitle().toUpperCase().charAt(0);
                if (!allChars.contains(""+letter)) {
                    allChars.add(""+letter);
                    mAlphaMap.put(allChars.size()-1, i);
                }
            }
            mAlphabetArray = allChars.toArray(new String[]{});
        }
    }

    private ActionBar getActionBar() {
        return ((ActionBarActivity) getActivity()).getSupportActionBar();
    }
}
