package org.kaaproject.kaa.demo.playerdemo.profile;

import java.util.ArrayList;
import java.util.List;

import org.kaa.config.ProfileSchema;
import org.kaaproject.kaa.client.profile.AbstractProfileContainer;

import config.system.ProfileProperty;

/** Profile container used to set up endpoint profile */
public class PlayerProfileContainer extends AbstractProfileContainer {

    public PlayerProfileContainer() {}

    @Override
    public ProfileSchema getProfile() {
        List<ProfileProperty> props = new ArrayList<>();
        props.add(new ProfileProperty("propName", "propValue"));
        return new ProfileSchema(props);
    }
}
