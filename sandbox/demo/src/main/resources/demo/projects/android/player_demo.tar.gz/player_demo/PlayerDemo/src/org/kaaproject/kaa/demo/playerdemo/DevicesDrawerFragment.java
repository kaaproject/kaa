/*
 * Copyright 2014 CyberVision, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.kaaproject.kaa.demo.playerdemo;

import java.util.ArrayList;
import java.util.List;

import org.kaaproject.kaa.demo.player.DeviceInfo;
import org.kaaproject.kaa.demo.player.DeviceInfoResponse;
import org.kaaproject.kaa.demo.playerdemo.command.CommandCallback;
import org.kaaproject.kaa.demo.playerdemo.data.DeviceInfoEntry;

import android.app.Activity;
import android.content.Context;
import android.content.res.Configuration;
import android.content.res.TypedArray;
import android.os.Bundle;
import android.support.v4.app.ActionBarDrawerToggle;
import android.support.v4.app.Fragment;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBar;
import android.support.v7.app.ActionBarActivity;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;

public class DevicesDrawerFragment extends Fragment {

    private PlayerActivity mMainActivity;
    
    private ActionBarDrawerToggle mDrawerToggle;

    private DrawerLayout mDrawerLayout;
    private ProgressBar mDevicesProgressBar;
    private ListView mDevicesListView;
    private Button mRefreshDevicesAction;
    private DeviceInfoAdapter mDevicesAdapter;
    private TextView mErrorTextView;
    private View mFragmentContainerView;
    private List<String> endpointKeys = new ArrayList<>();

    public DevicesDrawerFragment() {
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mDevicesAdapter = new DeviceInfoAdapter(new ArrayList<DeviceInfoEntry>(), getActionBar()
                .getThemedContext());
    }

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        setHasOptionsMenu(true);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
            Bundle savedInstanceState) {
        RelativeLayout view = (RelativeLayout)inflater.inflate(
                R.layout.devices_navigation_drawer, container, false);
        mDevicesListView = (ListView) view.findViewById(R.id.devicesList);
        mDevicesProgressBar = (ProgressBar) view.findViewById(R.id.progress);
        mDevicesListView
                .setOnItemClickListener(new AdapterView.OnItemClickListener() {
                    @Override
                    public void onItemClick(AdapterView<?> parent, View view,
                            int position, long id) {
                        selectItem(position);
                    }
                });
        mErrorTextView = (TextView) view.findViewById(R.id.errorTextView);
        mRefreshDevicesAction = (Button) view.findViewById(R.id.refreshDevicesAction);
        mRefreshDevicesAction.setEnabled(false);
        mRefreshDevicesAction.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				mDevicesProgressBar.setVisibility(View.VISIBLE);
				mErrorTextView.setVisibility(View.GONE);
				mDevicesListView.setVisibility(View.GONE);
				mRefreshDevicesAction.setEnabled(false);
				mDevicesAdapter.getItemList().clear();
				mDevicesAdapter.notifyDataSetChanged();
				mMainActivity.getPlayerController().getEndpointKeyList(new EndpointKeyListCallback());
			}
        	
        });
        
        mDevicesListView.setAdapter(mDevicesAdapter);
        mDevicesListView.setFastScrollEnabled(true);
        
        return view;
    }
    
    public void setUp(int fragmentId, DrawerLayout drawerLayout) {
        mFragmentContainerView = getActivity().findViewById(fragmentId);
        mDrawerLayout = drawerLayout;

        mDrawerLayout.setDrawerShadow(R.drawable.nav_shadow,
                GravityCompat.START);

        ActionBar actionBar = getActionBar();
        actionBar.setDisplayHomeAsUpEnabled(true);
        actionBar.setHomeButtonEnabled(true);

        mDrawerToggle = new ActionBarDrawerToggle(getActivity(), 
                                                  mDrawerLayout, 
                                                  R.drawable.ic_drawer,
                                                  R.string.navigation_drawer_open, 
                                                  R.string.navigation_drawer_close) {
            @Override
            public void onDrawerClosed(View drawerView) {
                super.onDrawerClosed(drawerView);
                if (!isAdded()) {
                    return;
                }

                getActivity().supportInvalidateOptionsMenu();
            }

            @Override
            public void onDrawerOpened(View drawerView) {
                super.onDrawerOpened(drawerView);
                if (!isAdded()) {
                    return;
                }
                getActivity().supportInvalidateOptionsMenu();
            }
        };

        mDrawerLayout.openDrawer(mFragmentContainerView);
        mDrawerLayout.post(new Runnable() {
            @Override
            public void run() {
                mDrawerToggle.syncState();
            }
        });

        mDrawerLayout.setDrawerListener(mDrawerToggle);
        
        /** Initialization of player controller instance. */
        mMainActivity.getPlayerController().init(new InitCallback());
    }

    class InitCallback implements CommandCallback<Void> {

		@Override
		public void onCommandFailure(Throwable t) {
	        Log.e("Kaa", "Player controller initialization failed", t);
	        String message;
	        if (t != null) {
	            message = "Unexpected error: " + t.getMessage();
	        }
	        else {
	            message = "Unknown error!";
	        }
	        onError(message);
		}

		@Override
		public void onCommandSuccess(Void result) {
			mMainActivity.getPlayerController().getEndpointKeyList(new EndpointKeyListCallback());
		}

		@Override
		public void onCommandTimeout() {
			onTimeout();			
		}
    	
    }
    
    class EndpointKeyListCallback implements CommandCallback<List<String>> {

		@Override
		public void onCommandFailure(Throwable t) {
			Log.e("Kaa", "Retrieving list of attached devices failed", t);
	        String message;
	        if (t != null) {
	            message = "Unexpected error: " + t.getMessage();
	        }
	        else {
	            message = "Unknown error!";
	        }
	        onError(message);
		}

		@Override
		public void onCommandSuccess(List<String> result) {
			setEndpointKeys(result);
			for (final String endpointKey : result) {
				Log.d("Kaa", "Get device info by endpoint key " + endpointKey);
				mMainActivity.getPlayerController().getDeviceInfo(endpointKey, new DeviceInfoCallback(endpointKey));
			}
		}

		@Override
		public void onCommandTimeout() {
			onTimeout();		
		}
    	
    }
    
    class DeviceInfoCallback implements CommandCallback<DeviceInfoResponse> {

    	private String endpointKey;
    	
    	DeviceInfoCallback(String endpointKey) {
    		this.endpointKey = endpointKey;
    	}
    	
		@Override
		public void onCommandFailure(Throwable t) {
			onGetDeviceInfoError(endpointKey);
		}

		@Override
		public void onCommandSuccess(DeviceInfoResponse result) {
			if (result != null && result.getDeviceInfo() != null) {
				addDevice(endpointKey, result.getDeviceInfo());
			}
		}

		@Override
		public void onCommandTimeout() {
			onGetDeviceInfoError(endpointKey);
		}
    }
    
    private void onTimeout() {
        mDevicesProgressBar.setVisibility(View.GONE);
        mErrorTextView.setVisibility(View.VISIBLE);
        mErrorTextView.setText("Unable to complete request within a given timeout!");
        mRefreshDevicesAction.setEnabled(true);
    }
    
    private void onError(final String message) {
        mDevicesProgressBar.setVisibility(View.GONE);
        mErrorTextView.setVisibility(View.VISIBLE);
        mErrorTextView.setText(message);
        mRefreshDevicesAction.setEnabled(true);
    }
    
    private void setEndpointKeys(List<String> endpointKeys) {
    	this.endpointKeys.addAll(endpointKeys);
    	if (this.endpointKeys.isEmpty()) {
            mDevicesProgressBar.setVisibility(View.GONE);
            mErrorTextView.setVisibility(View.VISIBLE);
            mRefreshDevicesAction.setEnabled(true);
            mErrorTextView.setText("No devices attached!");
    	}
    }
    
    private void onGetDeviceInfoError(String endpontKey) {
    	endpointKeys.remove(endpontKey);
    	if (endpointKeys.isEmpty() && mDevicesAdapter.getCount()==0) {
    		mDevicesProgressBar.setVisibility(View.GONE);
            mErrorTextView.setVisibility(View.VISIBLE);
            mRefreshDevicesAction.setEnabled(true);
            mErrorTextView.setText("No online devices found!");
    	}
    	if (endpointKeys.isEmpty()) {
    		mRefreshDevicesAction.setEnabled(true);
    	}
    }
    
    private void addDevice(String endpontKey, DeviceInfo deviceInfo) {
    	if (mDevicesAdapter.getCount()==0) {
    		mDevicesProgressBar.setVisibility(View.GONE);
    		mDevicesListView.setVisibility(View.VISIBLE);
    	}
    	mDevicesAdapter.addItem(new DeviceInfoEntry(endpontKey, deviceInfo));
    	mDevicesAdapter.notifyDataSetChanged();
    	endpointKeys.remove(endpontKey);
    	if (endpointKeys.isEmpty()) {
    		mRefreshDevicesAction.setEnabled(true);
    	}
    }
    
    class DeviceInfoAdapter extends ArrayAdapter<DeviceInfoEntry> {

        private List<DeviceInfoEntry> mDevices;
        private Context context;
        private int selectedTextColor;
        private int defTextColor;
        
        public DeviceInfoAdapter(List<DeviceInfoEntry> itemList, Context ctx) {
            super(ctx, android.R.layout.simple_list_item_1, itemList);
            this.mDevices = itemList;
            this.context = ctx;
            int[] textColorPrimaryAttr = new int[] { android.R.attr.textColorPrimary };
            TypedArray a = getActionBar().getThemedContext().obtainStyledAttributes(textColorPrimaryAttr);
            defTextColor = a.getColor(0, -1);
            a.recycle();        
            selectedTextColor = getResources().getColor(R.color.holo_blue_dark);
        }
        
        @Override
        public int getCount() {
            if (mDevices != null)
                return mDevices.size();
            return 0;
        }

        @Override
        public DeviceInfoEntry getItem(int position) {
            if (mDevices != null)
                return mDevices.get(position);
            return null;
        }

        @Override
        public long getItemId(int position) {
            if (mDevices != null)
                return mDevices.get(position).hashCode();
            return 0;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            View v = convertView;
            if (v == null) {
                LayoutInflater inflater = (LayoutInflater) 
                        context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
                v = inflater.inflate(R.layout.device_list_item, null);
            }
            DeviceInfoEntry entry = mDevices.get(position);
            TextView deviceNameView = (TextView) v.findViewById(R.id.deviceName);
            TextView deviceDetailsView = (TextView) v.findViewById(R.id.deviceDetails);
            ProgressBar progressView = (ProgressBar) v.findViewById(R.id.progress);
            
            if (position == mDevicesListView.getCheckedItemPosition()) {
                deviceNameView.setTextColor(selectedTextColor);
            }
            else {
                deviceNameView.setTextColor(defTextColor);
            }
            
            String details = "";
            if (entry.getDeviceInfo() != null) {
                details += entry.getDeviceInfo().getBrand() + " (" + entry.getDeviceInfo().getProduct() + ") - " + entry.getDeviceInfo().getManufacturer();
            }
            
            deviceDetailsView.setText(details);
            
            String deviceName = "Unknown device";
            if (entry.getDeviceInfo() != null) {
                progressView.setVisibility(View.GONE);
                deviceName = entry.getDeviceInfo().getModel();
            }
            else {
                progressView.setVisibility(View.VISIBLE);
            }
            deviceNameView.setText(deviceName);
            return v;
        }
        
        public List<DeviceInfoEntry> getItemList() {
            return mDevices;
        }
     
        public void setItemList(List<DeviceInfoEntry> itemList) {
            this.mDevices = itemList;
        }
        
        public void addItem(DeviceInfoEntry entry) {
        	this.mDevices.add(entry);
        }
        
    }

    public boolean isDrawerOpen() {
        return mDrawerLayout != null
                && mDrawerLayout.isDrawerOpen(mFragmentContainerView);
    }

    private void selectItem(int position) {
        if (mDevicesListView != null) {
        	mDevicesAdapter.notifyDataSetChanged();
            DeviceInfoEntry deviceInfo = mDevicesAdapter.getItem(position);
            if (deviceInfo.getDeviceInfo() != null) {
                if (mDrawerLayout != null) {
                    mDrawerLayout.closeDrawer(mFragmentContainerView);
                }
                if (mMainActivity != null) {
                	mMainActivity.onDeviceItemSelected(deviceInfo);
                }
            }
        }
    }

    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);
        try {
        	mMainActivity = (PlayerActivity) activity;
        } catch (ClassCastException e) {
            throw new ClassCastException(
                    "Activity must be instance of PlayerActivity.");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mMainActivity = null;
    }

    @Override
    public void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        mDrawerToggle.onConfigurationChanged(newConfig);
    }
    
    public ActionBarDrawerToggle getDrawerToggle() {
    	return mDrawerToggle;
    }


    private ActionBar getActionBar() {
        return ((ActionBarActivity) getActivity()).getSupportActionBar();
    }

    public static interface DeviceDrawerCallbacks {

    	void onDeviceItemSelected(DeviceInfoEntry deviceInfo);
    	
    }
}
