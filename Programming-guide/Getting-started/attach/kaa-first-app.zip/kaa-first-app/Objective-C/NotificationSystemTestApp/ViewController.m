/*
 * Copyright 2014-2015 CyberVision, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#import "ViewController.h"
#import "Kaa.h"

@interface ViewController () <KaaClientStateDelegate, NotificationTopicListDelegate, NotificationDelegate, ProfileContainer>

@property (nonatomic, strong) id<KaaClient> kaaClient;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    //Create a Kaa client with default Kaa context.
    self.kaaClient = [Kaa client];
    
    // A listener that listens to the notification topic list updates.
    [self.kaaClient addTopicListDelegate:self];
    
    // Add a notification listener that listens to all notifications.
    [self.kaaClient addNotificationDelegate:self];
    
    // Set up profile container, needed for ProfileManager
    [self.kaaClient setProfileContainer:self];
    
    // Start the Kaa client and connect it to the Kaa server.
    [self.kaaClient start];
}

- (void)onListUpdated:(NSArray *)list {
    NSLog(@"Topic list updated!");
    
    if ([list count] == 0) {
        NSLog(@"Topic list is empty!");
        return;
    }
    
    for (Topic *topic in list) {
        NSLog(@"Received topic with id %lld and name %@", topic.id, topic.name);
    }
}

- (KAAEmptyData *)getProfile {
    return [[KAAEmptyData alloc] init];
}

- (void)onNotification:(KAANotification *)notification withTopicId:(int64_t)topicId {
    NSLog(@"Received notification %@ for topic with id %lld", notification.message, topicId);
}

- (void)onStarted {
    NSLog(@"Kaa SDK client started!");
}

@end
