#include <memory>

#include <kaa/Kaa.hpp>
#include <kaa/logging/Log.hpp>
#include <kaa/logging/LoggingUtils.hpp>
#include <kaa/notification/INotificationTopicListListener.hpp>
#include <kaa/common/exception/UnavailableTopicException.hpp>

using namespace kaa;

class BasicNotificationListener : public INotificationListener {
public:
    virtual void onNotification(const std::string& topicId, const KaaNotification& notification)
    {
        std::cout << (boost::format("Notification for topic id '%1%' received") % topicId) << std::endl;
        std::cout << (boost::format("Notification body: '%1%'")
            % (notification.message.is_null() ? "" : notification.message.get_string())) << std::endl;
    }
};

class BasicNotificationTopicListListener : public INotificationTopicListListener {
public:
    BasicNotificationTopicListListener(IKaaClient& kaaClient) : kaaClient_(kaaClient) {}

    virtual void onListUpdated(const Topics& topics)
    {
        std::cout << ("Topic list was updated") << std::endl;
        if (!topics.empty())
            for (const auto& topic : topics)
                std::cout << (boost::format("Topic: id '%1%', name '%2%', type '%3%'")
                    % topic.id % topic.name % LoggingUtils::TopicSubscriptionTypeToString(topic.subscriptionType)) << std::endl;
    }

private:
    IKaaClient&    kaaClient_;
};

int main()
{
    Kaa::init();
    IKaaClient& kaaClient =  Kaa::getKaaClient();

    std::unique_ptr<INotificationTopicListListener> topicListListener(new BasicNotificationTopicListListener(kaaClient));
    kaaClient.addTopicListListener(*topicListListener);

    std::unique_ptr<INotificationListener> commonNotificationListener(new BasicNotificationListener);
    kaaClient.addNotificationListener(*commonNotificationListener);

    Kaa::start();

    return 0;
}
